/* eslint-disable*/

import React from 'react'
import { Row, Col } from 'reactstrap'
import SharePool from '../../../components/Share/SharePool'
import Container from "react-bootstrap/Container"
import Breadcrumb from "react-bootstrap/Breadcrumb"

const Share = () => (
  <div className="content">
    <Container fluid>
      <Breadcrumb/>
      <Row>
        <Col xs="12">

        </Col>
        <Col xs="12">

        </Col>
      </Row>
    </Container>
  </div>
)

export default Share
