import React from 'react'
import { BrowserRouter as Router } from 'react-router-dom'

const App = () => (
  //   const tempDisable = false

  <Router />
)

export default React.memo(App)
