import React from 'react'
import Loading from '../../assets/img/loading.png'

const SpartanLoading = () => <img src={Loading} alt="loading" />

export default SpartanLoading
