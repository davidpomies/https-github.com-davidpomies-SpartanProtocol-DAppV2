import { useSelector } from 'react-redux'

export const useUtilsMath = () => useSelector((state) => state.utilsMath)
