import { useSelector } from 'react-redux'

export const useUtilsPricing = () => useSelector((state) => state.utilsPricing)
